
<?php

echo " <table width='500' height='120' border='1'>";

for ($i=1; $i<=10; $i++) {               // 表格有 10 行
  echo "<tr>";
    for ($j=1; $j<=5; $j++) {         //每行有 5 個欄位
    echo "<td height='30'></td>";   // 欄位高 30 pix
           }
  echo "</tr>";
}

?>

