<html xmlns=”http://www.w3.org/1999/xhtml”>

<body>

<table width="1000" height="100" border="0">
    <caption><font size="6"><u><p>很堅固工程公司 報價單</p></u></font></caption>
    <tr height="50" align="left">
        <td>客戶名稱：</td><td width="400"></td>
        <td>報價日期：</td><td width="400"></td>
    </tr>

    <tr height="50" align="left">
        <td>客戶地址：</td><td width="400"></td>
        <td>客戶電話：</td><td width="400"></td>
    </tr>
</table>

<table width="1000" border="1">

    <tr height="50" align="center">
        <td width="50">項目</td>
        <td width="200">品   名</td>
        <td width="450">規   格</td>
        <td width="100">數   量</td>
        <td width="100">單   價</td>
        <td width="100">小  計</td>
    </tr>

    <?php
       for ($i=1; $i<=10; $i++) {
           echo "<tr height='50'>";
           for ($j=1; $j<=6; $j++) {
                   echo "<td></td>";
           }
           echo "</tr>";
        }
    ?>




</table>

<table width="1000" border="1">
    <tr height="50" align="left">
      <td width="200">總計</td>
      <td width="800"></td>
    </tr>
</font>
</table>
</body>
</html>

