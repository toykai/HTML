<?php
$username = $_POST["userName"];
$QQ = $_POST["ICQ"];
$lynr = $_POST["lynr"];

echo "XSS1: " . $username . "</br>";
echo "XSS2: " . $QQ . "</br>";
echo "XSS3: " . $lynr . "</br>";
?>


