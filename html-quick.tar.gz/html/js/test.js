<script src='//ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js'></script>
<script>
$.ajax({
type: "post",
data: {
"method": "write",
"name": "Wayne",
"sex": "male",
"remark": "測試寫入功能"
},
url: "https://script.google.com/macros/s/AKfycbwLtDI_xSQzOG57YtlUJ3QWmGvBfHfrFRM0L8cc_Pxj_KGGrbXZ/exec" // 填入網路應用程式網址
});
</script>




