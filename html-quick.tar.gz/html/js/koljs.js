// clipboard
$.fn.modal.Constructor.prototype._enforceFocus = function () {};
/* 複製內容功能設定 */
var clipboard = new ClipboardJS('.copy');

$(document).ready(function () {
    // toast
    $(".toast-trigger").click(function (e) {
        e.preventDefault();
        datatoast = $(this).attr("data-toast");
        if ($(this).hasClass("toast-auto") && !$(datatoast).is(":visible")) {
            $("#" + datatoast).fadeIn(200).delay(600).fadeOut(200);
        }
    });
    //tooltip 
    $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    })
    
});