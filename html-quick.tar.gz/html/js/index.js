

<script src='//ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js'></script>
<script>
let sendButton = document.querySelector('button');

function send() {
  let name = document.querySelector('#nameValue').value;
  let phone = document.querySelector('#phoneValue').value;
  $.ajax({
    type: "Get"
    url: "https://script.google.com/macros/s/AKfycbwLtDI_xSQzOG57YtlUJ3QWmGvBfHfrFRM0L8cc_Pxj_KGGrbXZ/exec",
    data: {
      "name": name, /* 屬性名稱需與 Google Sheet 相同 */
      "phone": phone, /* 屬性名稱需與 Google Sheet 相同 */
    },
    success: function(response) {
      if(response == "成功"){
        alert("成功");
      }
    },
  });
};

sendButton.addEventListener('click', send);
</script>


